let fname : String;
fname= 'test';
let age: Number;

let isvalid =boolean;

let dob: Date;
dob= new Date('3-mar-2008');
let salary : bigint;

let employee : any;

let emplist: string[] | number[];
