package com.cg.hotelroom.controller;

import java.util.ArrayList;
import java.util.Scanner;
import com.cg.hotelroom.dto.Hotel;
import com.cg.hotelroom.dto.RoomDetails;
import com.cg.hotelroom.dto.Users;
import com.cg.hotelroom.exception.HotelException;
import com.cg.hotelroom.service.HotelService;
import com.cg.hotelroom.service.HotelServiceImpl;
import com.cg.hotelroom.service.RoomDetailsService;
import com.cg.hotelroom.service.RoomDetailsServiceImpl;
import com.cg.hotelroom.service.UsersService;
import com.cg.hotelroom.service.UsersServiceImpl;

public class HotelClass {
	
     static HotelService service = new HotelServiceImpl();
     static UsersService service1= new UsersServiceImpl();
     static RoomDetailsService service2= new RoomDetailsServiceImpl();
     public static void main(String[] args) {
 		// TODO Auto-generated method stub
 		
 		int choice = 0;
 		try(Scanner sc = new Scanner(System.in))
		{
 			System.out.println("*************************************");
 			System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
 			System.out.println("Welcome in The World of Hotel Room Booking System");
 			System.out.println("***************************************");
 			System.out.println("1-Register");
 			System.out.println("2-Login ");
 			System.out.println("3-Exit");
 			System.out.println("Enter choice::");
 			
 			choice = sc.nextInt();
 			switch(choice){
 			case 1:
 			        System.out.println("1-Register as a Admin");
			        System.out.println("2-Register as a User");
		        	System.out.println("3- Exit");
		        	System.out.println("Enter choice::");
			
			        choice = sc.nextInt();
					    switch(choice) {
 			                case 1 : 
 			                     Users use= acceptUsersDetails();
 			                     if(use!=null){
 			            	       try
 			                	     {
 			    	        	   int id = service1.addUsers(use);
 					        	    	System.out.println("inserted and id = "+id);
 					                	} 
 			    	            catch(HotelException e)
 					            	  {
 				        			 System.out.println(e.getMessage());
 			                    	   }
 			                        } 
 			                     break;
 			               case 2 :
 			    	            Users use1= acceptUsersDetails();
  			                    if(use1!=null){
  			                	   try
  			                	   {
  			    	         	  int id = service1.addUsers(use1);
  					        		System.out.println("inserted and id = "+id);
  					            	} 
  			    	              catch(HotelException e)
  				             		{
  					        		System.out.println(e.getMessage());
  			    	                }
  			                     }
  			                    break;
 			              case 3:
				           	System.out.println("THANK YOU FOR USING OUR SERVICES! PLEASE VISIT AGAIN");
				         	System.exit(0);
					
				         default:
				         	System.out.println("INVALID CHOICE!"+"\n CHOOSE THE CORRECT OPTION");
				        	break;
			
				         }
 			case 2:
				System.out.println("1-Login as a Admin");
				System.out.println("2-Login as a User");
				System.out.println("3- Exit");
				
				System.out.println("Enter choice::");
				choice = sc.nextInt();
						switch(choice) 
				                  {
						case 1:
							 try
				 			    {
							     	
				 				     System.out.println("Welcome in The World of Hotel Room Booking System");
				 				     System.out.println("Enter Username");
				 				     String user_name= sc.next();
				 				    System.out.println("Enter Password");
				 				    String password=sc.next();
									boolean use=service1.checkLogin(user_name, password);
				 			    }
				 			    catch(HotelException e)
				 			    {
				 				System.out.println(e.getMessage());
				 			     }
							 break;
						case 2:
							 try
				 			    {
							     	
				 				     System.out.println("Welcome in The World of Hotel Room Booking System");
				 				     System.out.println("Enter Username");
				 				     String user_name= sc.next();
				 				    System.out.println("Enter Password");
				 				    String password=sc.next();
									boolean use =service1.checkLogin(user_name, password);
				 			    }
				 			    catch(HotelException e)
				 			    {
				 				System.out.println(e.getMessage());
				 			     }
							 
						case 3:
							System.out.println("THANK YOU FOR USING OUR SERVICES! PLEASE VISIT AGAIN");
							System.exit(0);
							break;
							
				}
 			     break;       
 			}
 			System.out.println("do you want to continue 1-yes 0-No");
			choice = sc.nextInt();
 			
			do
			{
				System.out.println("1-Add Hotel");
				System.out.println("2-Remove Hotel");
				System.out.println("3-Search By Id");
				System.out.println("4- update Hotel");
				System.out.println("Enter choice::");
				choice = sc.nextInt();
				switch(choice)
				{
					case 1 : 
						
						Hotel hot = acceptHotelDetails(); 
					if(hot!=null){	
					try
					{
						int id = service.addHotel(hot);
						System.out.println("inserted and id = "+id);
					}
					catch(HotelException e)
					{
						System.out.println(e.getMessage());
					}}
					break;
					case 2: System.out.println("Enter to id to remove::");
					int id = sc.nextInt();
					try
					{
						Hotel hot1 = service.removeHotel(id);
						System.out.println("removed Hotel "+hot1);
					}
					catch(HotelException e)
					{
						System.out.println(e.getMessage());
					}
					break;
					case 3 : System.out.println("Enter id to search Hotel::");
					int eid = sc.nextInt();
					try
					{
						Hotel ref = service.getHotelById(eid);
						System.out.println("hot "+ref);
					}
					catch(HotelException e)
					{
						System.out.println(e.getMessage());
					}
					break;
					case 4: System.out.println("Enter id::");
					int hotId = sc.nextInt();
					int avg_rate_per_night = sc.nextInt();
					try{
						Hotel eObj = service.updateHotel(hotId, avg_rate_per_night);
						System.out.println("updated = "+eObj);
					}
					catch(HotelException e)
					{
						System.out.println(e.getMessage());
					}
					break;
				}
				System.out.println("do you want to continue 1-yes 0-No");
				choice = sc.nextInt();
			}
			while(choice!=0);
		
		do {
			System.out.println("1-Add RoomDetails");
			System.out.println("2-Show RoomDetails");
			System.out.println("Enter choice::");
			choice = sc.nextInt();
			switch(choice)
			{
				case 1 : 
					RoomDetails room = acceptRoomDetailsDetails(); 
					if(room!=null){	
					try
					{
						int id = service2.addRoomDetails(room);
						System.out.println("inserted and id = "+id);
					}
					catch(HotelException e)
					{
						System.out.println(e.getMessage());
					}}
					break;
				case 2:
					try {
						ArrayList<RoomDetails>list=service2.getAllRoomDetails();
						for(RoomDetails obj:list)
						{
							System.out.println(obj);
						}
						}
						catch(HotelException e)
						{
							System.out.println(e.getMessage());
						}
						break;
					}
			System.out.println("do you want to continue 1-yes 0-No");
			choice = sc.nextInt();
		}
		while(choice!=0);
		}
 		
}

	private static RoomDetails acceptRoomDetailsDetails() {
		RoomDetails room= null;
		Scanner sc = new Scanner(System.in);
		while(true)
		{
			System.out.println("Enter Room id::");
			String room_id = sc.next();
			  if(!service2.validateRoom_id(room_id))
			    {
				continue;
			    }
			  else
			  {
				  while(true)
			  	{
					System.out.println("Enter Room no::");
					String room_no = sc.next();
					  if(!service2.validateRoom_no(room_no))
					    {
						continue;
					    }
					  else
					  {
						  while(true)
						  	{
								System.out.println("Enter Room Type::");
								String room_type = sc.next();
								  if(!service2.validateRoom_type(room_type))
								    {
									continue;
								    }
								  else
								  {
									  while(true)
									  	{
											System.out.println("Enter Room Per Night Rate::");
											int per_night_rate = sc.nextInt();
											  if(!service2.validatePer_night_rate(per_night_rate))
											    {
												continue;
											    }
											  else
											  {
												  System.out.println("Enter Room Availability::");
													String availability = sc.next();
													  if(!service2.validateAvailability(availability))
													    {
														continue;
													    }
													  if (availability!=null)
													  {
														  room=new RoomDetails();
														  
														  room.setRoom_id(room_id);
														  room.setRoom_no(room_no);
														  room.setRoom_type(room_type);
														  room.setPer_night_rate(per_night_rate);
														  room.setAvailability(availability);
														  return room;
														 
													  } 
											  }
								  }
					         }
				    	}
					 }
			   }
			}
	    }	  
	}

	private static Users acceptUsersDetails() {
		Users use=null;
		Scanner sc = new Scanner(System.in);
		while(true)
		{
			System.out.println("Enter Users name::");
			String user_name = sc.next();
			  if(!service1.validateUser_name(user_name))
			    {
				continue;
			    }
			  else
			  {
				  while(true)
					{
						System.out.println("Enter Users Password::");
						String password = sc.next();
						  if(!service1.validatePassword(password))
						    {
							continue;
						    }
						  else
						  { 
						 while(true)
							{
							System.out.println("Enter Users Role::");
							String role = sc.next();
						    if(!service1.validateRole(role))
								    {
									continue;
								    }
						    else
							 { 
							  while(true)
								{
						 		System.out.println("Enter Users Mobile no::");
								String mobile_no = sc.next();
								  if(!service1.validateMobile_no(mobile_no))
								    {
									continue;
								    }
									  else
									 {  
								  while(true)
										{
										System.out.println("Enter Users Phone no::");
										String phone = sc.next();
									  if(!service1.validatePhone(phone))
									    {
										continue;
									    }
									   else
									    { 
										  while(true)
											{
											System.out.println("Enter Users Address::");
											String address = sc.next();
								    		  if(!service1.validateAddress(address))
											    {
												continue;
											    }
								    			  else
									    		  {  
								    				System.out.println("Enter Users email::");
													String email = sc.next();
												  if(!service1.validateEmail(email))
												    {
													continue;
												    }
								    				  if(email!=null)
													  {  
													  use =new Users();
														use.setUser_name(user_name);
														use.setPassword(password);
														use.setRole(role);
														use.setMobile_no(mobile_no);
														use.setPhone(phone);
														use.setAddress(address);
														use.setEmail(email);
														return use;
														
														}
													} 
								    								  
											    } 
											 }
										  }
							    	  }
						          }
			                   } 
		                    }
		            	}
		           }
 	          } 
         } 
   }

	private static Hotel acceptHotelDetails() {
		Hotel hot = null;
		Scanner sc = new Scanner(System.in);
		while(true)
		{
			System.out.println("Enter City name::");
			String city = sc.next();
			  if(!service.validateCity(city))
			    {
				continue;
			    }
			  else
			  {
		while(true)
		{
			System.out.println("Enter Hotel name::");
			String hotel_name = sc.next();
				if(!service.validateName(hotel_name))
				{
				continue;
				}
				else
				{
		while(true)
		{
			System.out.println("Enter Address::");
			String address = sc.next();
				if(!service.validateAddress(address))
				{
				continue;
				}
				else
				{
		while(true)
		{
			System.out.println("Enter Description::");
			String description = sc.next();
				if(!service.validateDescription(description))
				{
				continue;
				}
				else
				{
		while(true)
		{
			System.out.println("Enter Rate per Night::");
			int avg_rate_per_night = sc.nextInt();
				if(!service.validateRate(avg_rate_per_night))
				{
			    	continue;
				}
				else
				{
		while(true)
		{
	    	System.out.println("Enter Phoneno1::");
			String phone_no1 = sc.next();
				if(!service.validatePhoneno1(phone_no1))
				{
					continue;
				}
				else
				{
		while(true)
		{
		    System.out.println("Enter Phoneno2::");
	    	String phone_no2 = sc.next();
				if(!service.validatePhoneno2(phone_no2))
				{
				 	continue;
				}
				else
				{		
		while(true)
		{
		    System.out.println("Enter Rating::");
			String rating = sc.next();
			   if(!service.validateRating(rating))
				{
					continue;
				}
				else
				{	
		while(true)
		{
		    System.out.println("Enter email id::");
			String email = sc.next();
		      if(!service.validateEmail(email))
				{
					continue;
				}
		     else
		 	{	
		
		 	 System.out.println("Enter fax::");
		 	 String fax = sc.next();
		 	  if(!service.validateFax(fax))
		 	  {
		 			continue;
		    	}
		 	 if(fax!=null)
				{	

		 		 	      hot =new Hotel();
		                  hot.setCity(city);
	                      hot.setHotel_name(hotel_name);
	                	  hot.setAddress(address);
	                	  hot.setDescription(description);
		                  hot.setAvg_rate_per_night(avg_rate_per_night);
		                  hot.setPhone_no1(phone_no1);
		                  hot.setPhone_no2(phone_no2);
	                 	  hot.setRating(rating);
		                  hot.setEmail(email);
	                      hot.setFax(fax);
		                return hot;
		                }
		 	           }
		              }
		            }
			       }
		          }
	            }
		      }
	         }
		    }
           }
          }
         }
	    }
       }
	  }
	 }	 
    }		
  }
  }	
}		
			
		
	

	