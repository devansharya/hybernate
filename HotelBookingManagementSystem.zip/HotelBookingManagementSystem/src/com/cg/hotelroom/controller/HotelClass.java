package com.cg.hotelroom.controller;

import java.util.Scanner;

import com.cg.hotelroom.dto.Hotel;
import com.cg.hotelroom.dto.Users;
import com.cg.hotelroom.exception.HotelException;
import com.cg.hotelroom.service.HotelService;
import com.cg.hotelroom.service.HotelServiceImpl;
import com.cg.hotelroom.service.UsersService;
import com.cg.hotelroom.service.UsersServiceImpl;

public class HotelClass {
	
     static HotelService service = new HotelServiceImpl();
     static UsersService service1= new UsersServiceImpl();
     public static void main(String[] args) {
 		// TODO Auto-generated method stub
 		
 		int choice = 0;
 		try(Scanner sc = new Scanner(System.in))
		{
 			System.out.println("*************************************");
 			System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
 			System.out.println("Welcome in The World of Hotel Room Booking System");
 			System.out.println("***************************************");
 			System.out.println("1-Login by Admin");
 			System.out.println("2-Login by Customer");
 			//String username = sc.next();
 			//System.out.println("Enter Password for login");
 			//String password = sc.next(); 
 			choice = sc.nextInt();
 			switch(choice){
 			    case 1 : 
 			       Users use= acceptUsersDetails();
 			       if(use!=null){
 			    	   try
 			    	   {
 			    		  int id = service1.addUsers(use);
 							System.out.println("inserted and id = "+id);
 						} 
 			    	  catch(HotelException e)
 						{
 							System.out.println(e.getMessage());
 			    	   }
 			       }
 			
 			
 			    try
 			    {
			     	//Users use= service2.checkLogin(username, password);
 				     System.out.println("Welcome in The World of Hotel Room Booking System");
 			    }
 			    catch(HotelException e)
 			    {
 				System.out.println(e.getMessage());
 			     }
 			}
			do
			{
				System.out.println("1-Add Hotel");
				System.out.println("2-Remove Hotel");
				System.out.println("3-Search By Id");
				System.out.println("4- update Hotel");
				System.out.println("Enter choice::");
				choice = sc.nextInt();
				switch(choice)
				{
					case 1 : 
						
						Hotel hot = acceptHotelDetails(); 
					if(hot!=null){	
					try
					{
						int id = service.addHotel(hot);
						System.out.println("inserted and id = "+id);
					}
					catch(HotelException e)
					{
						System.out.println(e.getMessage());
					}}
					break;
					case 2: System.out.println("Enter to id to remove::");
					int id = sc.nextInt();
					try
					{
						Hotel hot1 = service.removeHotel(id);
						System.out.println("removed Hotel "+hot1);
					}
					catch(HotelException e)
					{
						System.out.println(e.getMessage());
					}
					break;
					case 3 : System.out.println("Enter id to search Hotel::");
					int eid = sc.nextInt();
					try
					{
						Hotel ref = service.getHotelById(eid);
						System.out.println("hot "+ref);
					}
					catch(HotelException e)
					{
						System.out.println(e.getMessage());
					}
					break;
					case 4: System.out.println("Enter id::");
					int hotId = sc.nextInt();
					int avg_rate_per_night = sc.nextInt();
					try{
						Hotel eObj = service.updateHotel(hotId, avg_rate_per_night);
						System.out.println("updated = "+eObj);
					}
					catch(HotelException e)
					{
						System.out.println(e.getMessage());
					}
					break;
				}
				System.out.println("do you want to continue 1-yes 0-No");
				choice = sc.nextInt();
			}while(choice!=0);
		}
}

	private static Users acceptUsersDetails() {
		Users use=null;
		Scanner sc = new Scanner(System.in);
		while(true)
		{
			System.out.println("Enter Users name::");
			String user_name = sc.next();
			  if(!service.validateUser_name(user_name))
			    {
				continue;
			    }
			  else
			  {
				  while(true)
					{
						System.out.println("Enter Users Password::");
						String password = sc.next();
						  if(!service.validatePassword(password))
						    {
							continue;
						    }
						  else
						  { 
							  while(true)
								{
									System.out.println("Enter Users Role::");
									String role = sc.next();
									  if(!service.validateRole(role))
									    {
										continue;
									    }
									  else
									  { 
										  while(true)
											{
												System.out.println("Enter Users Mobile no::");
												String mobile_no = sc.next();
												  if(!service.validateMobile_no(mobile_no))
												    {
													continue;
												    }
												  else
												  {  
													  while(true)
														{
															System.out.println("Enter Users Phone no::");
															String phone = sc.next();
															  if(!service.validatePhone(phone))
															    {
																continue;
															    }
															  else
															  { 
																  while(true)
																	{
																		System.out.println("Enter Users Address::");
																		String address = sc.next();
																		  if(!service.validateAddress(address))
																		    {
																			continue;
																		    }
																		  else
																		  {  
																					System.out.println("Enter Users email::");
																					String email = sc.next();
																					  if(!service.validateEmail(email))
																					    {
																						continue;
																					    }
																					  if(email!=null)
																					  {  
																						  use =new Users();
																						  
																					  }
																		  }
																			  
																		  }
															  }
												  }
									  }
						  }
			  }
		return null;
	}

	private static Hotel acceptHotelDetails() {
		Hotel hot = null;
		Scanner sc = new Scanner(System.in);
		while(true)
		{
			System.out.println("Enter City name::");
			String city = sc.next();
			  if(!service.validateCity(city))
			    {
				continue;
			    }
			  else
			  {
		while(true)
		{
			System.out.println("Enter Hotel name::");
			String hotel_name = sc.next();
				if(!service.validateName(hotel_name))
				{
				continue;
				}
				else
				{
		while(true)
		{
			System.out.println("Enter Address::");
			String address = sc.next();
				if(!service.validateAddress(address))
				{
				continue;
				}
				else
				{
		while(true)
		{
			System.out.println("Enter Description::");
			String description = sc.next();
				if(!service.validateDescription(description))
				{
				continue;
				}
				else
				{
		while(true)
		{
			System.out.println("Enter Rate per Night::");
			int avg_rate_per_night = sc.nextInt();
				if(!service.validateRate(avg_rate_per_night))
				{
			    	continue;
				}
				else
				{
		while(true)
		{
	    	System.out.println("Enter Phoneno1::");
			String phone_no1 = sc.next();
				if(!service.validatePhoneno1(phone_no1))
				{
					continue;
				}
				else
				{
		while(true)
		{
		    System.out.println("Enter Phoneno2::");
	    	String phone_no2 = sc.next();
				if(!service.validatePhoneno2(phone_no2))
				{
				 	continue;
				}
				else
				{		
		while(true)
		{
		    System.out.println("Enter Rating::");
			String rating = sc.next();
			   if(!service.validateRating(rating))
				{
					continue;
				}
				else
				{	
		while(true)
		{
		    System.out.println("Enter email id::");
			String email = sc.next();
		      if(!service.validateEmail(email))
				{
					continue;
				}
		     else
		 	{	
		
		 	 System.out.println("Enter fax::");
		 	 String fax = sc.next();
		 	  if(!service.validateFax(fax))
		 	  {
		 			continue;
		    	}
		 	 if(fax!=null)
				{	

		 		 	      hot =new Hotel();
		                  hot.setCity(city);
	                      hot.setHotel_name(hotel_name);
	                	  hot.setAddress(address);
	                	  hot.setDescription(description);
		                  hot.setAvg_rate_per_night(avg_rate_per_night);
		                  hot.setPhone_no1(phone_no1);
		                  hot.setPhone_no2(phone_no2);
	                 	  hot.setRating(rating);
		                  hot.setEmail(email);
	                      hot.setFax(fax);
		                return hot;
		                }
		 	           }
		              }
		            }
			       }
		          }
	            }
		      }
	         }
		    }
           }
          }
         }
	    }
       }
	  }
	 }	 
    }		
  }
  }	
}		
			
		
	

	