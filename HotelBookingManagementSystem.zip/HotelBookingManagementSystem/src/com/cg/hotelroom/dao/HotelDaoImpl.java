package com.cg.hotelroom.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import com.cg.hotelroom.dto.Hotel;
import com.cg.hotelroom.exception.HotelException;
import com.cg.hotelroom.util.DBUtil;
import com.cg.logger.MyLogger;


public class HotelDaoImpl implements HotelDao{

	Connection con;
	Logger logger;
	
	public HotelDaoImpl()
	{
		con=DBUtil.getConnect();
		logger = MyLogger.getLogger();
	}
	
	public int getHotelId()throws HotelException {
		
		logger.info("In getHotelId");
		int id = 0;
		String qry = "SELECT eId_seq.CURRVAL FROM DUAL";
		try{
			  Statement stmt = con.createStatement();
			  ResultSet rs = stmt.executeQuery(qry);
			if(rs.next())
			  {
				id = rs.getInt(1);
				logger.info("Got Hotel With Id"+id);
			  }
		  }
		catch(SQLException e)
			 {
				logger.error("Error"+e.getMessage());
				throw new HotelException(e.getMessage());
			 }
			logger.info("Completed getHotelId");
		
		return id;
		
	}
	
	@Override
	public int addHotel(Hotel hot) throws HotelException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Hotel getHotelById(int hotId) throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Hotel> getAllHotel() throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

}
