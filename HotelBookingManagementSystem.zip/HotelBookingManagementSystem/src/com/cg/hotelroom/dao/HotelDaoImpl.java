package com.cg.hotelroom.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.cg.hotelroom.dto.Hotel;
import com.cg.hotelroom.exception.HotelException;
import com.cg.hotelroom.util.DBUtil;
import com.cg.logger.MyLogger;


public class HotelDaoImpl implements HotelDao{

	Connection con;
	Logger logger;
	
	public HotelDaoImpl()
	{
		con = DBUtil.getConnect();
		logger = MyLogger.getLogger();
	}
	
	public int getHotelId()throws HotelException {
		
		logger.info("In getHotelId");
		int id = 0;
		String qry = "SELECT eId_seq.CURRVAL FROM DUAL";
		try{
			  Statement stmt = con.createStatement();
			  ResultSet rs = stmt.executeQuery(qry);
			if(rs.next())
			  {
				id = rs.getInt(1);
				logger.info("Got Hotel With Id"+id);
			  }
		  }
		catch(SQLException e)
			 {
				logger.error("Error"+e.getMessage());
				throw new HotelException(e.getMessage());
			 }
			logger.info("Completed getHotelId");
		
		return id;
		
	}
	
	@Override
	public int addHotel(Hotel hot) throws HotelException {
		
		logger.info("In Add Hotel");
		logger.info("Input is "+hot);
		int id = 0;
		String qry = "INSERT INTO HotelJEE VALUES(eId_seq.NEXTVAL,?,?,?,?,?,?,?,?,?,?)";
		
		String city = hot.getCity();
		String hotel_name = hot.getHotel_name();
		String address = hot.getAddress();
		String description = hot.getDescription();
		int avg_rate_per_night = hot.getAvg_rate_per_night();
	    String phone_no1 = hot.getPhone_no1();
		String phone_no2 = hot.getPhone_no2();
	    String rating = hot.getRating();
		String email = hot.getEmail();
		String fax = hot.getFax();
		
		try
		{
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setString(1, city);
			pstmt.setString(2, hotel_name);
			pstmt.setString(3, address);
			pstmt.setString(4, description);
			pstmt.setInt(5, avg_rate_per_night);
			pstmt.setString(6, phone_no1);
			pstmt.setString(7, phone_no2);
			pstmt.setString(8, rating);
			pstmt.setString(9, email);
			pstmt.setString(10, fax);
			
			int row = pstmt.executeUpdate();
			if(row > 0)
			{
				id = getHotelId();
				logger.info("Inserted successfully and Id is = "+id);
			}
			else
				throw new HotelException("unable to insert"+hot);
			
		}
		catch(SQLException e)
		{
			logger.error("Error in insert = "+e.getMessage());
			throw new HotelException(e.getMessage());
		}
		return id;
			

	}

	@Override
	public Hotel removeHotel(int hotId) throws HotelException {
		Hotel hot = null;
		String qry = "DELETE FROM HotelJEE WHERE hotId=?";
		
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setInt(1, hotId);
			hot = getHotelById(hotId);
			int row = pstmt.executeUpdate();
			if(hot==null)
			{
				throw new HotelException("emp with id "+hotId+"not found");
			}
			else if(row > 0)
			{
				System.out.println("Deleted Employee with Id "+hotId);
				
			}
			
		}
		catch(SQLException e)
		{
			throw new HotelException(e.getMessage());
		}
		return hot;
	
	}



	@Override
	public Hotel updateHotel(int hotId, int avg_rate_per_night) throws HotelException {
		
		Hotel hot = getHotelById(hotId);
		if(hot==null)
			throw new HotelException("Hotel with id "+hotId+"Not found");
		else
		{
			String qry = "UPDATE HotelJEE SET avg_rate_per_night=? WHERE hotId=?";
			try{
				PreparedStatement pstmt = con.prepareStatement(qry);
				pstmt.setInt(1, avg_rate_per_night);
				pstmt.setInt(2, hotId);
				int row = pstmt.executeUpdate();
				if(row > 0)
				{
					System.out.println("updated successfully");
					hot = getHotelById(hotId);
				}      
			}
			catch(SQLException e)
			{
				throw new HotelException(e.getMessage());
			}
			
		}
		return hot;
	}

	
	@Override
	public Hotel getHotelById(int hotId) throws HotelException {
		Hotel hot = null;
		String qry = "SELECT * FROM HotelJEE WHERE hotId=?";
		try
		{
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setInt(1, hotId);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next())
			{
		         int id = rs.getInt(1);
				String city = rs.getString(2);
				String hotel_name = rs.getString(3);
				String address = rs.getString(4);
				String description = rs.getString(5);
				int avg_rate_per_night = rs.getInt(6);
			    String phone_no1 = rs.getString(7);
				String phone_no2 = rs.getString(8);
			    String rating = rs.getString(9);
				String email = rs.getString(10);
				String fax = rs.getString(11);
				
				hot = new Hotel(id,city,hotel_name,address,description,avg_rate_per_night,phone_no1,phone_no2,rating,email,fax);
				
	        }
			else
				throw new HotelException("Hotel with id "+hotId+"not found");
		}
		catch(SQLException e)
		{
			throw new HotelException(e.getMessage());
		}
		return hot;
}
	}
