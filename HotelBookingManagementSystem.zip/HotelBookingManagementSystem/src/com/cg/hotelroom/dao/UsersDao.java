package com.cg.hotelroom.dao;

import com.cg.hotelroom.dto.Hotel;
import com.cg.hotelroom.dto.Users;
import com.cg.hotelroom.exception.HotelException;

public interface UsersDao {

	public boolean checkLogin(int id,String password) throws HotelException; 
	int addUsers(Users use)throws HotelException;
	
	
}
