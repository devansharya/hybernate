package com.cg.hotelroom.dao;

import com.cg.hotelroom.dto.Users;
import com.cg.hotelroom.exception.HotelException;

public interface UsersDao {

	public Users checkLogin(String username,String password) throws HotelException; 
	
	
}
