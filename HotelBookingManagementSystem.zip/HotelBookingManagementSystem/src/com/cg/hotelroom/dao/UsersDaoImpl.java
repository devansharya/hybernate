package com.cg.hotelroom.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.cg.hotelroom.dto.Users;
import com.cg.hotelroom.exception.HotelException;
import com.cg.hotelroom.util.DBUtil;
import com.cg.logger.MyLogger;


public class UsersDaoImpl implements UsersDao{

	Connection con;
	Logger logger;
	
	public UsersDaoImpl()
	{
		con = DBUtil.getConnect();
		logger = MyLogger.getLogger();
	}
	
	@Override
	public Users checkLogin(String username, String password)throws HotelException {
		
		Users user = null;
		String qry= "SELECT username ,password FROM Users";
				
		try {

			PreparedStatement pstmt = con.prepareStatement(qry);
			 ResultSet rs = pstmt.executeQuery(qry);
			
			while (rs.next()) {
				
				String uname= rs.getString(username);
				String pass= rs.getString(password);
				
				if (username.equals(uname) && password.equals(pass)){
					
					System.out.println("Access Granted! Welcome!");
					}
				else if(username.equals(uname)){
					System.out.println("Invalid Password");
				}
				else if(password.equals(pass)){
					System.out.println("Invalid Username");
				}
				
				else
				{
					System.out.println("Invalid Username & Invalid Password");
				}
				rs.close();
			}
		}
		catch(SQLException e){
			System.out.println(e);
		}
		
		return user;
	}
}
