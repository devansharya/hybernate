package com.cg.hotelroom.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.cg.hotelroom.dto.Users;
import com.cg.hotelroom.exception.HotelException;
import com.cg.hotelroom.util.DBUtil;
import com.cg.logger.MyLogger;


public class UsersDaoImpl implements UsersDao{

	Connection con;
	Logger logger;
	
	public UsersDaoImpl()
	{
		con = DBUtil.getConnect();
		logger = MyLogger.getLogger();
	}
	
	@Override
	public boolean checkLogin(int id, String password)throws HotelException {
		
		//Users user = null;
		//String pass= null;
		String qry= "SELECT password FROM UsersJEE where id=?";
				
		try {

			PreparedStatement pstmt = con.prepareStatement(qry);
		//	pstmt.setString(2,user_name );
			pstmt.setString(3,password );
			 ResultSet rs = pstmt.executeQuery();
			
			while (rs.next()) {
				
				String uname= rs.getString(2);
				String pass= rs.getString(3);
				
				if ( pass.equals(password)){
					//return true;
					System.out.println("Access Granted! Welcome!");
					}
				/*else if(user_name.equals(uname)){
					System.out.println("Invalid Password");
				}
				else if(password.equals(pass)){
					System.out.println("Invalid Username");
				}
				
				else
				{
					System.out.println("Invalid Username & Invalid Password");
				}
				rs.close();
				*/
			}
		}
		catch(SQLException e){
			System.out.println(e);
		}
		
		return false;
	}
	
public int getUsersId()throws HotelException {
		
		logger.info("In getUsersId");
		int id = 0;
		String qry = "SELECT eId_seq.CURRVAL FROM DUAL";
		try{
			  Statement stmt = con.createStatement();
			  ResultSet rs = stmt.executeQuery(qry);
			if(rs.next())
			  {
				id = rs.getInt(1);
				logger.info("Got Users With Id"+id);
			  }
		  }
		catch(SQLException e)
			 {
				logger.error("Error"+e.getMessage());
				throw new HotelException(e.getMessage());
			 }
			logger.info("Completed getUsersId");
		
		return id;
		
	}

	@Override
	public int addUsers(Users use) throws HotelException {

		logger.info("In Add Users");
		logger.info("Input is "+use);
		int id = 0;
		
		String qry = "INSERT INTO UsersJEE VALUES(eId_seq.NEXTVAL,?,?,?,?,?,?,?)";
		
		String User_name=use.getUser_name();
		String password= use.getPassword();
		String role= use.getMobile_no();
		String mobile_no= use.getMobile_no();
		String phone=use.getPhone();
		String address= use.getAddress();
		String email = use.getEmail();
		
		try
		{
			PreparedStatement pstmt= con.prepareStatement(qry);
			pstmt.setString(2,User_name );
			pstmt.setString(3,password);
			pstmt.setString(4,role );
			pstmt.setString(5,mobile_no );
			pstmt.setString(6,phone );
			pstmt.setString(7,address );
			pstmt.setString(8,email );
		
		int row = pstmt.executeUpdate();
		if(row > 0)
		{
			id = getUsersId();
			logger.info("Inserted successfully and Id is = "+id);
		}
		else
			throw new HotelException("unable to insert"+use);
		}
		catch(SQLException e)
		{
			logger.error("Error in insert = "+e.getMessage());
			throw new HotelException(e.getMessage());
		}
		
		return id;
	}
}
