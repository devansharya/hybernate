package com.cg.hotelroom.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.cg.hotelroom.dto.Users;
import com.cg.hotelroom.exception.HotelException;
import com.cg.hotelroom.util.DBUtil;
import com.cg.logger.MyLogger;


public class UsersDaoImpl implements UsersDao{

	Connection con;
	Logger logger;
	
	public UsersDaoImpl()
	{
		con = DBUtil.getConnect();
		logger = MyLogger.getLogger();
	}
	
	@Override
	public Users checkLogin(String username, String password)throws HotelException {
		
		Users user = null;
		String qry= "SELECT username ,password FROM Users";
				
		try {

			PreparedStatement pstmt = con.prepareStatement(qry);
			 ResultSet rs = pstmt.executeQuery(qry);
			
			while (rs.next()) {
				
				String uname= rs.getString(username);
				String pass= rs.getString(password);
				
				if (username.equals(uname) && password.equals(pass)){
					
					System.out.println("Access Granted! Welcome!");
					}
				else if(username.equals(uname)){
					System.out.println("Invalid Password");
				}
				else if(password.equals(pass)){
					System.out.println("Invalid Username");
				}
				
				else
				{
					System.out.println("Invalid Username & Invalid Password");
				}
				rs.close();
			}
		}
		catch(SQLException e){
			System.out.println(e);
		}
		
		return user;
	}
	
public int getUsersId()throws HotelException {
		
		logger.info("In getUsersId");
		int id = 0;
		String qry = "SELECT eId_seq.CURRVAL FROM DUAL";
		try{
			  Statement stmt = con.createStatement();
			  ResultSet rs = stmt.executeQuery(qry);
			if(rs.next())
			  {
				id = rs.getInt(1);
				logger.info("Got Users With Id"+id);
			  }
		  }
		catch(SQLException e)
			 {
				logger.error("Error"+e.getMessage());
				throw new HotelException(e.getMessage());
			 }
			logger.info("Completed getUsersId");
		
		return id;
		
	}

	@Override
	public int addUsers(Users use) throws HotelException {

		logger.info("In Add Users");
		logger.info("Input is "+use);
		int id = 0;
		
		String qry = "INSERT INTO UsersJEE VALUES(eId_seq.NEXTVAL,?,?,?,?,?,?,?)";
		
		String User_name=use.getUser_name();
		String password= use.getPassword();
		String role= use.getMobile_no();
		String mobile_no= use.getMobile_no();
		String phone=use.getPhone();
		String address= use.getAddress();
		String email = use.getEmail();
		
		try
		{
			PreparedStatement pstmt= con.prepareStatement(qry);
			pstmt.setString(1,User_name );
			pstmt.setString(1,password);
			pstmt.setString(1,role );
			pstmt.setString(1,mobile_no );
			pstmt.setString(1,phone );
			pstmt.setString(1,address );
			pstmt.setString(1,email );
		
		int row = pstmt.executeUpdate();
		if(row > 0)
		{
			id = getUsersId();
			logger.info("Inserted successfully and Id is = "+id);
		}
		else
			throw new HotelException("unable to insert"+use);
		}
		catch(SQLException e)
		{
			logger.error("Error in insert = "+e.getMessage());
			throw new HotelException(e.getMessage());
		}
		
		return id;
	}
}
