package com.cg.hotelroom.dao;
import java.util.ArrayList;
import com.cg.hotelroom.dto.Hotel;
import com.cg.hotelroom.exception.HotelException;

public interface HotelDao {
	
	int addHotel(Hotel hot)throws HotelException;
	Hotel getHotelById(int hotId)throws HotelException;
	ArrayList<Hotel>getAllHotel()throws HotelException;
	
	
}
