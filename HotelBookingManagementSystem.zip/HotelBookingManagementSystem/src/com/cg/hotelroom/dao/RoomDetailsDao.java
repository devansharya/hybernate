package com.cg.hotelroom.dao;

import java.util.ArrayList;


import com.cg.hotelroom.dto.RoomDetails;
import com.cg.hotelroom.exception.HotelException;

public interface RoomDetailsDao {
	int addRoomDetails(RoomDetails room)throws HotelException;
	ArrayList<RoomDetails> getAllRoomDetails() throws HotelException;
}
