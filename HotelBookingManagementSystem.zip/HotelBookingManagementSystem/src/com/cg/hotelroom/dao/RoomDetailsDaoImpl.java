package com.cg.hotelroom.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.cg.hotelroom.dto.RoomDetails;
import com.cg.hotelroom.exception.HotelException;
import com.cg.hotelroom.util.DBUtil;
import com.cg.logger.MyLogger;

public class RoomDetailsDaoImpl implements RoomDetailsDao{


	Connection con;
	Logger logger;
	
	public RoomDetailsDaoImpl()
	{
		con = DBUtil.getConnect();
		logger = MyLogger.getLogger();
	}
	
public int getRoomDetailsId()throws HotelException {
		
		logger.info("In getRoomDetaisId");
		int id = 0;
		String qry = "SELECT eId_seq.CURRVAL FROM DUAL";
		try{
			  Statement stmt = con.createStatement();
			  ResultSet rs = stmt.executeQuery(qry);
			if(rs.next())
			  {
				id = rs.getInt(1);
				logger.info("Got RoomDetails With Id"+id);
			  }
		  }
		catch(SQLException e)
			 {
				logger.error("Error"+e.getMessage());
				throw new HotelException(e.getMessage());
			 }
			logger.info("Completed getRoomDetaisId");
		
		return id;
		
	}
	
	@Override
	public int addRoomDetails(RoomDetails room) throws HotelException {
		logger.info("In Add RoomDetails");
		logger.info("Input is "+room);
		int id = 0;
		String qry = "INSERT INTO RoomDetailsJEE VALUES(eId_seq.NEXTVAL,?,?,?,?,?)";
		String room_id=room.getRoom_id();
		String room_no= room.getRoom_no();
		String room_type=room.getRoom_type();
		int per_night_rate=room.getPer_night_rate();
		String availability=room.getAvailability();
		
		try
		{
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setString(2,room_id);
			pstmt.setString(3,room_no);
			pstmt.setString(4,room_type);
			pstmt.setInt(5,per_night_rate);
			pstmt.setString(6,availability);
			
			int row = pstmt.executeUpdate();
			if(row > 0)
			{
				id = getRoomDetailsId();
				logger.info("Inserted successfully and Id is = "+id);
			}
			else
				throw new HotelException("unable to insert"+room);
			
		}
		catch(SQLException e)
		{
			logger.error("Error in insert = "+e.getMessage());
			throw new HotelException(e.getMessage());
		}
		return id;
	}

	@Override
	public ArrayList<RoomDetails> getAllRoomDetails() throws HotelException {
		ArrayList<RoomDetails>list = new ArrayList<RoomDetails>();
		String qry = "SELECT * FROM RoomDetailsJEE";
		try
		{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			while(rs.next())
			{
				int id = rs.getInt(1);
				String room_id = rs.getString(2);
				String room_no = rs.getString(3);
				String room_type = rs.getString(4);
				int per_night_rate= rs.getInt(5);
				String availability=rs.getString(6);
				RoomDetails room=new RoomDetails(id,room_id,room_no,room_type,per_night_rate,availability);
				list.add(room);
			}
		}
		catch(SQLException e)
		{
			throw new HotelException(e.getMessage());
		}
		return list;
	}
	
}


