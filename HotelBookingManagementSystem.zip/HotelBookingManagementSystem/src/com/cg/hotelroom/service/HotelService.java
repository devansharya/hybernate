package com.cg.hotelroom.service;

import com.cg.hotelroom.dto.Hotel;
import com.cg.hotelroom.exception.HotelException;

public interface HotelService {

	int addHotel(Hotel hot)throws HotelException;
	Hotel removeHotel(int hotId)throws HotelException;
	Hotel updateHotel(int hotId,int avg_rate_per_night )throws HotelException;
	Hotel getHotelById(int hotId)throws HotelException;
	public boolean validateCity(String city);
	public boolean validateName(String hotel_name);
	public boolean validateAddress(String address);
	public boolean validateDescription(String description);
	public boolean validateRate(int avg_rate_per_night);
	public boolean validatePhoneno1(String phone_no1);
	public boolean validatePhoneno2(String phone_no2);
	public boolean validateRating(String rating);
	public boolean validateEmail(String email);
	public boolean validateFax(String fax);
	
}
