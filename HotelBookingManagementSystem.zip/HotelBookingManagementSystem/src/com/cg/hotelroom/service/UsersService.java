package com.cg.hotelroom.service;

import com.cg.hotelroom.dto.Users;
import com.cg.hotelroom.exception.HotelException;

public interface UsersService {
	public Users checkLogin(String username,String password) throws HotelException; 
}
