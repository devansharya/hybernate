package com.cg.hotelroom.service;

import com.cg.hotelroom.dto.Users;
import com.cg.hotelroom.exception.HotelException;

public interface UsersService {
	public boolean checkLogin(String username,String password) throws HotelException; 
	int addUsers(Users use)throws HotelException;
	public boolean validateUser_name(String user_name);
	boolean validatePassword(String password);
	boolean validateRole(String role);
	boolean validateAddress(String address);
	boolean validateEmail(String email);
	boolean validatePhone(String phone);
	boolean validateMobile_no(String mobile_no);
	boolean checkLogin(int id, String password) throws HotelException;
}
