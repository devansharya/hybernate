package com.cg.hotelroom.service;

import java.util.ArrayList;

import com.cg.hotelroom.dto.RoomDetails;
import com.cg.hotelroom.exception.HotelException;

public interface RoomDetailsService {

	int addRoomDetails(RoomDetails room)throws HotelException;
	ArrayList<RoomDetails> getAllRoomDetails() throws HotelException;
	boolean validateRoom_id(String room_id);
	boolean validateRoom_no(String room_no);
	boolean validateRoom_type(String room_type);
	boolean validatePer_night_rate(int per_night_rate);
	boolean validateAvailability(String availability);
}
