package com.cg.hotelroom.service;

import java.util.regex.Pattern;

import com.cg.hotelroom.dao.HotelDao;
import com.cg.hotelroom.dao.UsersDao;
import com.cg.hotelroom.dao.UsersDaoImpl;
import com.cg.hotelroom.dto.Users;
import com.cg.hotelroom.exception.HotelException;

public class UsersServiceImpl implements UsersService{

	UsersDao dao;
	
	public void setDao(UsersDao dao)
	{
		this.dao = dao;
	}
	public UsersServiceImpl()
	{
		dao= new UsersDaoImpl();
	}
	
	
	@Override
	public boolean checkLogin(int id, String password)
			throws HotelException {
		
		return dao.checkLogin(id, password);
	}
	@Override
	public int addUsers(Users use) throws HotelException {
		
		return dao.addUsers(use);
	}
	@Override
	public boolean validateUser_name(String user_name) {
		String pattern = "[A-z]{1}[a-z]{2,}";
		if(Pattern.matches(pattern,user_name))
		{
			return true;
		}
		else
			return false;
	}
	@Override
	public boolean validatePassword(String password) {
		String pattern = "[a-z]{2,8}";
		if(Pattern.matches(pattern, password))
		{
			return true;
		}
		else
			return false;
	}
	@Override
	public boolean validateRole(String role) {
		String pattern = "[A-z]{1}[a-z]{2,}";
		if(Pattern.matches(pattern,role))
		{
			return true;
		}
		else
			return false;
	}
	@Override
	public boolean validateMobile_no(String mobile_no) {
		String pattern = "[0-9]{6,10}";
		if(Pattern.matches(pattern,mobile_no))
		{
			return true;
		}
		else
			return false;
	}
	@Override
	public boolean validatePhone(String phone) {
		String pattern = "[0-9]{6,10}";
		if(Pattern.matches(pattern,phone))
		{
			return true;
		}
		else
			return false;
	}
	@Override
	public boolean validateAddress(String address) {
		String pattern = "[A-z]{1}[a-z]{2,}";
		if(Pattern.matches(pattern,address))
		{
			return true;
		}
		else
			return false;
	}
	@Override
	public boolean validateEmail(String email) {
		String pattern = "^[A-Za-z0-9+_.-]+@(.+)$";
		if(Pattern.matches(pattern,email))
		{
			return true;
		}
		else
			return false;
	}
	@Override
	public boolean checkLogin(String username, String password) throws HotelException {
		// TODO Auto-generated method stub
		return false;
	}
	
}
