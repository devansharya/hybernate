package com.cg.hotelroom.service;

import com.cg.hotelroom.dao.HotelDao;
import com.cg.hotelroom.dao.UsersDao;
import com.cg.hotelroom.dao.UsersDaoImpl;
import com.cg.hotelroom.dto.Users;
import com.cg.hotelroom.exception.HotelException;

public class UsersServiceImpl implements UsersService{

	UsersDao dao;
	
	public void setDao(UsersDao dao)
	{
		this.dao = dao;
	}
	public UsersServiceImpl()
	{
		dao= new UsersDaoImpl();
	}
	
	
	@Override
	public Users checkLogin(String username, String password)
			throws HotelException {
		
		return dao.checkLogin(username, password);
	}

	
	
	
}
