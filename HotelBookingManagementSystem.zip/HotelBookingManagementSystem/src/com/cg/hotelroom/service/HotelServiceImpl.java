package com.cg.hotelroom.service;

import java.util.regex.Pattern;

import com.cg.hotelroom.dao.HotelDao;
import com.cg.hotelroom.dao.HotelDaoImpl;
import com.cg.hotelroom.dto.Hotel;
import com.cg.hotelroom.exception.HotelException;

public class HotelServiceImpl implements HotelService{

	HotelDao dao;
	
	public void setDao(HotelDao dao)
	{
		this.dao = dao;
	}
	public HotelServiceImpl()
	{
		dao= new HotelDaoImpl();
	}
	
	

	public int addHotel(Hotel hot) throws HotelException {
		// TODO Auto-generated method stub
		return dao.addHotel(hot);
	}
	
	public Hotel removeHotel(int hotId) throws HotelException {
		// TODO Auto-generated method stub
		return dao.removeHotel(hotId);
	}

	public Hotel updateHotel(int hotId, int avg_rate_per_night)throws HotelException {
		// TODO Auto-generated method stub
		return dao.updateHotel(hotId, avg_rate_per_night);
	}
	
	public Hotel getHotelById(int hotId) throws HotelException {
		// TODO Auto-generated method stub
		return dao.getHotelById(hotId);
	}
	@Override
	public boolean validateCity(String city) {
		String pattern = "[A-z]{1}[a-z]{2,}";
		if(Pattern.matches(pattern,city))
		{
			return true;
		}
		else
			return false;
	}
	@Override
	public boolean validateName(String hotel_name) {
		String pattern = "[A-z]{1}[a-z]{2,}";
		if(Pattern.matches(pattern,hotel_name))
		{
			return true;
		}
		else
			return false;
	}
	@Override
	public boolean validateAddress(String address) {
		String pattern = "[A-z]{1}[a-z]{2,}";
		if(Pattern.matches(pattern,address))
		{
			return true;
		}
		else
			return false;
	}
	@Override
	public boolean validateDescription(String description) {
		String pattern = "[A-z]{1}[a-z]{2,}";
		if(Pattern.matches(pattern,description))
		{
			return true;
		}
		else
			return false;
	}
	@Override
	public boolean validateRate(int avg_rate_per_night) {
		String pattern = "[0-9]{4,6}";
		String rate = ""+avg_rate_per_night;
		if(Pattern.matches(pattern,rate))
		{
			return true;
		}
		else 
			return false;
	}
	@Override
	public boolean validatePhoneno1(String phone_no1) {
		String pattern = "[0-9]{4,6}";
		String phone1 = ""+phone_no1;
		if(Pattern.matches(pattern,phone1))
		{
			return true;
		}
		else 
			return false;
	}
	@Override
	public boolean validatePhoneno2(String phone_no2) {
		String pattern = "[0-9]{4,6}";
		String phone2 = ""+phone_no2;
		if(Pattern.matches(pattern,phone2))
		{
			return true;
		}
		else 
			return false;
	}
	@Override
	public boolean validateRating(String rating) {
		String pattern = "[A-z]{1}[a-z]{2,}";
		if(Pattern.matches(pattern,rating))
		{
			return true;
		}
		else
			return false;
	}
	@Override
	public boolean validateEmail(String email) {
		String pattern = "[A-z]{1}[a-z]{2,}";
		if(Pattern.matches(pattern,email))
		{
			return true;
		}
		else
			return false;
	}
	@Override
	public boolean validateFax(String fax) {
		String pattern = "[0-9]{4,6}";
		String ph = ""+fax;
		if(Pattern.matches(pattern,ph))
		{
			return true;
		}
		else 
			return false;
	}

}
