package com.cg.hotelroom.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.hotelroom.dao.HotelDao;
import com.cg.hotelroom.dao.RoomDetailsDao;
import com.cg.hotelroom.dao.RoomDetailsDaoImpl;
import com.cg.hotelroom.dto.RoomDetails;
import com.cg.hotelroom.exception.HotelException;

public class RoomDetailsServiceImpl implements RoomDetailsService{

	RoomDetailsDao dao;
	public void setDao(RoomDetailsDao dao)
	{
		this.dao = dao;
	}
	public RoomDetailsServiceImpl()
	{
		dao= new RoomDetailsDaoImpl();
	}
	
	@Override
	public int addRoomDetails(RoomDetails room) throws HotelException {
		// TODO Auto-generated method stub
		return dao.addRoomDetails(room);
	}

	@Override
	public ArrayList<RoomDetails> getAllRoomDetails() throws HotelException {
		// TODO Auto-generated method stub
		return dao.getAllRoomDetails();
	}
	@Override
	public boolean validateRoom_id(String room_id) {
		String pattern = "[0-9]{3,6}";
		String rate = ""+room_id;
		if(Pattern.matches(pattern,rate))
		{
			return true;
		}
		else 
			return false;
		
	}
	@Override
	public boolean validateRoom_no(String room_no) {
		String pattern = "[0-9]{3,6}";
		String rate = ""+room_no;
		if(Pattern.matches(pattern,rate))
		{
			return true;
		}
		else 
			return false;
	
	}
	@Override
	public boolean validateRoom_type(String room_type) {
		String pattern = "[a-z]{1,}";
		if(Pattern.matches(pattern,room_type))
		{
			return true;
		}
		else
			return false;
		
	}
	@Override
	public boolean validatePer_night_rate(int per_night_rate) {
		String pattern = "[0-9]{3,6}";
		String rate = ""+per_night_rate;
		if(Pattern.matches(pattern,rate))
		{
			return true;
		}
		else 
		return false;
	}
	
	@Override
	public boolean validateAvailability(String availability) {
		String pattern = "[a-z]{2,}";
		if(pattern.matches(pattern))
		{
			return true;
		}
		else
			return false;
	}


}
