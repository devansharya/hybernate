package com.cg.hotelroom.dto;

import java.time.LocalDate;

public class BookingDetails {

	private String booking_id;
	private String room_id;
	private String user_id;
	private LocalDate booked_date;
	private LocalDate booked_to;
	private int no_of_adults;
	
	
	public BookingDetails() {
		super();
		// TODO Auto-generated constructor stub
	}


	public BookingDetails(String booking_id, String room_id, String user_id, LocalDate booked_date, LocalDate booked_to,
			int no_of_adults) {
		super();
		this.booking_id = booking_id;
		this.room_id = room_id;
		this.user_id = user_id;
		this.booked_date = booked_date;
		this.booked_to = booked_to;
		this.no_of_adults = no_of_adults;
	}


	public String getBooking_id() {
		return booking_id;
	}


	public String getRoom_id() {
		return room_id;
	}


	public String getUser_id() {
		return user_id;
	}


	public LocalDate getBooked_date() {
		return booked_date;
	}


	public LocalDate getBooked_to() {
		return booked_to;
	}


	public int getNo_of_adults() {
		return no_of_adults;
	}


	@Override
	public String toString() {
		return "BookingDetails [booking_id=" + booking_id + ", room_id=" + room_id + ", user_id=" + user_id
				+ ", booked_date=" + booked_date + ", booked_to=" + booked_to + ", no_of_adults=" + no_of_adults + "]";
	}

	
	
}
