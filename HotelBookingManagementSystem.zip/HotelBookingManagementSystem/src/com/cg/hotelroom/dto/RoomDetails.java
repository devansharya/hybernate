package com.cg.hotelroom.dto;


public class RoomDetails {

	private String hotel_id;
	private String room_id;
	private String room_no;
	private String room_type;
	private int per_night_rate;
	private boolean availability;
	
	
	
	public RoomDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RoomDetails(String hotel_id, String room_id, String room_no, String room_type, int per_night_rate,
			boolean availability) {
		super();
		this.hotel_id = hotel_id;
		this.room_id = room_id;
		this.room_no = room_no;
		this.room_type = room_type;
		this.per_night_rate = per_night_rate;
		this.availability = availability;
		
	}

	public String getHotel_id() {
		return hotel_id;
	}

	public String getRoom_id() {
		return room_id;
	}
	
	public String getRoom_no() {
		return room_no;
	}
	public String getRoom_type() {
		return room_type;
	}
	
	public int getPer_night_rate() {
		return per_night_rate;
	}

	public boolean isAvailability() {
		return availability;
	}



	@Override
	public String toString() {
		return "RoomDetails [hotel_id=" + hotel_id + ", room_id=" + room_id + ", room_no=" + room_no + ", room_type="
				+ room_type + ", per_night_rate=" + per_night_rate + ", availability=" + availability + "]";
	}
	
	
	
}
