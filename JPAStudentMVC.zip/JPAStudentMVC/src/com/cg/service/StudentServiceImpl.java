package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;



import org.springframework.stereotype.Service;

import com.cg.dao.StudentRepository;
import com.cg.entities.Student;
@Service
@Transactional
public class StudentServiceImpl implements StudentService{


	@Autowired
	private StudentRepository employeeRepository;
	
	@Override
	public Student save(Student employee) {
		// TODO Auto-generated method stub
		 return employeeRepository.save(employee);
	}

	@Override
	public List<Student> loadAll() {
		// TODO Auto-generated method stub
		return employeeRepository.loadAll();
	}

}
