package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.Student;

@Repository
public class StudentRepositoryImpl implements StudentRepository {

	
	@PersistenceContext
	private EntityManager entityManager;
	

	@Override
	public Student save(Student employee) {
		entityManager.persist(employee);
		entityManager.flush();	//required to reflect changes on database
		
		return employee;
	}

	@Override
	public List<Student> loadAll() {
		TypedQuery<Student> query = 
				entityManager.
				createQuery
				("SELECT e FROM Student e", 
						Student.class);
		return query.getResultList();
	}

}
