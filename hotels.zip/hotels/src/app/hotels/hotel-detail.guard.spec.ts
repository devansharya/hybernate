import { TestBed, async, inject } from '@angular/core/testing';

import { HotelDetailGuard } from './hotel-detail.guard';

describe('HotelDetailGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HotelDetailGuard]
    });
  });

  it('should ...', inject([HotelDetailGuard], (guard: HotelDetailGuard) => {
    expect(guard).toBeTruthy();
  }));
});
