import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import {  IHotel } from './hotel';
import { HotelService } from './hotel.service';


@Component({
  templateUrl: './hotel-detail.component.html',
  styleUrls: ['./hotel-detail.component.css']
})
export class HotelDetailComponent implements OnInit {
  pageTitle = 'Hotel Detail';
  errorMessage = '';
Hotel: IHotel | undefined;
  hotel: any;

  constructor(private route: ActivatedRoute,
    private router: Router,
    private hotelService:HotelService) {
  }

  ngOnInit() {
    const param = this.route.snapshot.paramMap.get('id');
    if (param) {
      const id = +param;
      this.getHotel(id);
    }
  }

  getHotel(id: number) {
    this.hotelService.getHotel(id).subscribe(
      hotel => this.hotel = hotel,
      error => this.errorMessage = <any>error);
  }

  onBack(): void {
    this.router.navigate(['/hotels']);
  }

}
