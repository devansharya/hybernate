import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { HotelListComponent } from './hotel-list.component';
import { HotelDetailComponent } from './hotel-detail.component';
import { ConvertToSpacesPipe } from '../shared/convert-to-spaces.pipe';
import { HotelDetailGuard } from './hotel-detail.guard';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'hotels', component: HotelListComponent },
      {
        path: 'hotels/:id',
        canActivate: [HotelDetailGuard],
        component: HotelDetailComponent
      },
    ]),
    SharedModule
  ],
  declarations: [
    HotelListComponent,
    HotelDetailComponent,
    ConvertToSpacesPipe
  ]
})
export class HotelModule { }
