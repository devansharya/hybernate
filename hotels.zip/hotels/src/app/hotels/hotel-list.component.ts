import { Component, OnInit } from '@angular/core';

import { IHotel } from './hotel';
import { HotelService } from './hotel.service';

@Component({
  templateUrl: './hotel-list.component.html',
  styleUrls: ['./hotel-list.component.css']
})
export class HotelListComponent implements OnInit {
  pageTitle = 'Hotel List';
  imageWidth = 50;
  imageMargin = 2;
  showImage = false;
  errorMessage = '';

  _listFilter = '';
  filteredHotels: any;
  get listFilter(): string {
    return this._listFilter;
  }
  set listFilter(value: string) {
    this._listFilter = value;
    this.filteredHotels = this.listFilter ? this.performFilter(this.listFilter) : this.hotels;
  }

  //filteredHotels: IHotel[] = [];
  hotels: IHotel[] = [];

  constructor(private hotelService: HotelService) {

  }

  onRatingClicked(message: string): void {
    this.pageTitle = 'Hotel List: ' + message;
  }

  performFilter(filterBy: string): IHotel[] {
    filterBy = filterBy.toLocaleLowerCase();
    return this.filteredHotels.filter((hotel: IHotel) =>
     hotel.hotelName.toLocaleLowerCase().indexOf(filterBy) !== -1);
  }

  toggleImage(): void {
    this.showImage = !this.showImage;
  }

  ngOnInit(): void {
    this.hotelService.getHotels().subscribe(
      hotels => {
        this.hotels = hotels;
        this.filteredHotels = this.hotels;
      },
      error => this.errorMessage = <any>error
    );
  }
}
