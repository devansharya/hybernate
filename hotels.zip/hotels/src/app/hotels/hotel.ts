export interface IHotel {
  hotelId: number;
  hotelName: string;
  hotelCode: string;
  checkInDate: string;
  checkOutDate: string;
  price: number;
  description: string;
  starRating: number;
  imageUrl: string;
}

