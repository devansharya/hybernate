package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.StudentDao;
import com.cg.entities.Student;




@Service
public class StudentServiceImpl implements StudentService {

	
	@Autowired
	private StudentDao studentDao;
	
	
	
	@Override
	public void add(Student student) {
		// TODO Auto-generated method stub
		studentDao.add(student);
	}

	@Override
	public void edit(Student student) {
		// TODO Auto-generated method stub
		studentDao.edit(student);
	}

	@Override
	public void delete(int studentId) {
		// TODO Auto-generated method stub
		studentDao.delete(studentId);
	}

	@Override
	public Student getStudent(int studentId) {
		// TODO Auto-generated method stub
		return studentDao.getStudent(studentId);
	}

	@Override
	public List getAllStudent() {
		// TODO Auto-generated method stub
		return studentDao.getAllStudent();
	}

}
