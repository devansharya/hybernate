import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { BookingServiceService } from '../service/mobile-service.service';
import { Booking } from '../model/MobileModel';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {
booking:Booking[];
  constructor(private bookingservice :BookingServiceService,private router:Router) { }

  ngOnInit() {
    this.booking=this.bookingservice.getList();
  }
  delete(index:number){
    var ans = confirm("Are you sure You want to delete?")
    if(ans){
      this.bookingservice.deleteBooking(index);
    }
  }
}
