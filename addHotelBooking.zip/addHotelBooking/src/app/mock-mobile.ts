import { Booking } from './model/MobileModel';
export const BOOKING: Booking[]=[];