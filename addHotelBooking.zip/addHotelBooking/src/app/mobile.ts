export class Booking{
  
    public bookingId: number;
    public roomId: number;
    public userId: number;
   public bookedFrom: Date;
   public bookedTo: Date;
   public noOfAdults: number;
   public noOfChildren: number;
    public amount : number;
 
   
}