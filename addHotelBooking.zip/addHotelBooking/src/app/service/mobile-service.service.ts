import { Injectable } from '@angular/core';
import { Booking } from '../model/MobileModel';


@Injectable({
  providedIn: 'root'
})
export class BookingServiceService {
booking:Booking[]=[];
  constructor() { }
  //add data in database
  insertBooking(booking: Booking){
    this.booking.push(booking);
  }

  //return whole database
  getList(): Booking[]{
    return this.booking;
  }
  //delete a entry
  deleteBooking(index:number){
    return this.booking.splice(index,1);
  }
}


  