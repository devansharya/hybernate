import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { BookingServiceService } from '../service/mobile-service.service';
import { Booking } from '../model/MobileModel';

import { BOOKING } from '../mock-mobile';


@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
booking : Booking
  constructor(private bookingservice:BookingServiceService,private router:Router) {
    this.booking= new Booking();
   
   }
   onSubmit(form){
    console.log(BOOKING)
    BOOKING.push(form.value)
    this.bookingservice.insertBooking(this.booking);
    this.router.navigate(['/show']);

   }

  ngOnInit() {
   
  }

}

  