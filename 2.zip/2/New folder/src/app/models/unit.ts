export class Unit {
    id: number;
    name: string;
    rating: number;
}
