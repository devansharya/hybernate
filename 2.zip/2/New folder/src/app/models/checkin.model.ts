export class CheckIn {
    employeeSin: string;
    hotelId: number;
    roomNumber: number;
    startDate: Date;
    endDate: Date;
    payment: number;
}