export class HotelChain {
    hcName: string;
    numberOfHotels: number;
}