package com.spring.dao;

import java.util.List;

import com.spring.exception.StudentException;
import com.spring.model.Student;

public interface StudentDao {
	public int addStudent(Student s);
	public List<Student> getAll();
	public Student getById(int id);
	public void updateStudent(Student stu,Student stus);
	public void deleteStudent(int id)throws StudentException;
}
