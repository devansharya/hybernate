package com.spring.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.spring.exception.StudentException;
import com.spring.model.Student;
import com.spring.service.StudentService;



@Controller
public class StudentController {

	Student stu1 ;
	Student stu = new Student();
	@Autowired
	StudentService service;
	@RequestMapping("/home")
	
	public String showHome()
	{
		return "home";
	}@RequestMapping("/home1")
	
	public String showHome1()
	{
		return "home1";
	}
	
	@RequestMapping(value="/addStudent",method=RequestMethod.GET)
	public String showStudent(Model model,HttpServletRequest request)
	{
		String view = "StudAdd";
		
		
		
		ServletContext context = request.getServletContext();
		
		
		model.addAttribute("student", new Student());

		 return view;
		
	}
	@RequestMapping(value="/addition",method=RequestMethod.POST)
	public String processRegister(Model model,
			@Valid @ModelAttribute("student")Student student,BindingResult result)
	{
		String view = "";

		if (result.hasErrors()) {
			view = "StudAdd";
		} else {
			
			service.addStudent(student);
			model.addAttribute("stu", student);
			view = "AddSuccess";
		}
		return view;		
	}
	
	@RequestMapping(value="/find")
	public String showViewbyID(Model model)
	{
		String view="viewById";
		model.addAttribute("student", new Student());
		return view;
	}
	@RequestMapping(value="/findId",method=RequestMethod.POST)
	public String processSearch(Model model,@ModelAttribute("student")Student student) throws StudentException
	{
		String view="home1";
		Student stu = null;
	  stu = service.getById(student.getId());
	  if(stu !=null)
	  {
		  model.addAttribute("s", stu);
		  model.addAttribute("student", new Student());
		  view="viewSuccess";
		  
	  }else
	  {
		  throw new StudentException("Id does not exist in the table");
		  
	  }
	   return view;
	  
	}
	
	@RequestMapping(value="/display")
	public String processShow(Model model) throws StudentException
	{
		String view="home1";
		List<Student> list = service.getAll();
	  if(list !=null)
	  {
		  model.addAttribute("listStu", list);
		  view="show";
		  
	  }else
	  {
		  throw new StudentException("display is not correct");
		  
	  }
	   return view;
	  
	}
	
	@RequestMapping(value="/update")
	public String showUpdate(Model model, HttpServletRequest request)
	{
		
		model.addAttribute("student", new Student());
		String view="viewUpdate";
		model.addAttribute("msg", "Welcome to Updation Page");
		return view;
		
		}
	@RequestMapping(value="/updateId",method=RequestMethod.POST)
	public String processUpdate(Model model,@Valid @ModelAttribute("student")Student student,BindingResult result,HttpServletRequest request) throws StudentException
	{
		String view = "home1";
		stu1 = service.getById(student.getId());
		
		System.out.println(student.getId());
		if(stu1!=null)
		{
			model.addAttribute("student", stu1);
			
			
			view="updateStu";
			return view;	
		}else
		{
			throw new StudentException("Sorry ID not found");
		}
     }
	
	@RequestMapping(value="/updation",method=RequestMethod.POST)
	public String processUpdation(Model model,@Valid @ModelAttribute("student")Student student,BindingResult result,HttpServletRequest request) throws StudentException
	{
		service.updateStudent(student,stu1);
		String view="UpdateSuccess";
		model.addAttribute("mymessage", "Your data has benn succesfully updated");
		model.addAttribute("student", student);
		return view;
	}
	
	@RequestMapping(value="/delete")
	public String showDeletebyID(Model model)
	{
		String view="deleteById";
		model.addAttribute("student", new Student());
		return view;
	}
	
	@RequestMapping(value="/deleteId",method=RequestMethod.POST)
	public String processDeletion(Model model,@Valid @ModelAttribute("student")Student student,BindingResult result,HttpServletRequest request) throws StudentException
	{
		String view="";
      Student stu=service.getById(student.getId());
      if(stu!=null)
      {
    	  service.deleteStudent(stu.getId());
    	   view="DeleteSuccess";
      }
		
		model.addAttribute("mymessage", "Your data has been succesfully deleted");
		model.addAttribute("student", student);
		return view;
	}
}
